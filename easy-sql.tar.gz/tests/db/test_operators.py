from __future__ import annotations

from unittest import TestCase


class Test(TestCase):
    def test_base_filter(self):
        pass

    def test_boolean_operator(self):
        pass

    def test_and(self):
        pass

    def test_or(self):
        pass
