from __future__ import annotations

from unittest import TestCase


class TestDBSettings(TestCase):
    pass
