# Changelog

<!--next-version-placeholder-->

## v1.0.0 (2023-01-12)
### Feature
* Model managing ([`3d91aa4`](https://sgithub.fr.world.socgen/OSS/easy-sqla/commit/3d91aa40ea10a3d8bd30aa972a635ab7f8465261))

## v0.1.0 (2022-11-14)
### Feature
* Make base_model configuration more easier ([`b5dfbd3`](https://github.com/skouriba/sqlalchemy-django-wrapper/commit/b5dfbd3a3437ca4ffa3da864a8451e64acc75f76))

### Fix
* **test:** Fix wrong return in utils.get_model_from_rel ([`86be64d`](https://github.com/skouriba/sqlalchemy-django-wrapper/commit/86be64d2f692d3da5db2da0e9e34b09af8abf2fa))
* **semantic-release:** Setuo it into pipeline ([`85cff61`](https://github.com/skouriba/sqlalchemy-django-wrapper/commit/85cff6117e1eeba246c31e32e6aca5483ea566bd))
* Update pyproject.toml ([`2b4f4f4`](https://github.com/skouriba/sqlalchemy-django-wrapper/commit/2b4f4f4aa8865f808c5056d2d78d4223814355fe))