
class CompositePK(dict):
    pass
