from __future__ import annotations

import logging

logger = logging.getLogger("sqlalchemy_django_wrapper")
